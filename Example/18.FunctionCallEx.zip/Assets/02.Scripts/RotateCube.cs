﻿using UnityEngine;
using System.Collections;

public class RotateCube : MonoBehaviour 
{
	public static int numX = 0; 
	
	public static int AddTwoNum (int x, int y) 
	{
		return x + y;
	}

	public void Rotate1 () 
	{
		transform.Rotate(Vector3.up * 90.0f);
	}
	
	private void Rotate2 () 
	{
		transform.Rotate(Vector3.up * 90.0f * -1);
	}
	
}
