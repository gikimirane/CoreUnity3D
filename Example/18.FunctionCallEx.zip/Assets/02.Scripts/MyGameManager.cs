﻿using UnityEngine;
using System.Collections;

public class MyGameManager : MonoBehaviour 
{
	GameObject obj = null;

	void Start () 
	{
		obj = GameObject.Find("Cube");
	}
	
	void OnGUI ()
	{
		if (GUI.Button(new Rect(30, 50, 180, 30)," Function Call ( Public ) "))
	    {
		    // 특정 Object안에 있는 Script의 메소드 호출
			RotateCube script = obj.GetComponent<RotateCube>();
			script.Rotate1();	
	    }
	    
		if (GUI.Button(new Rect(30, 100, 180, 30)," Function Call ( Private ) "))
	    {
			// 메시지 보내기
			obj.SendMessage("Rotate2", SendMessageOptions.DontRequireReceiver);
	    }
	    
		if (GUI.Button(new Rect(30, 150, 180, 30)," Static "))
	    {
			// static 함수나 변수는 바로 접근 가능
			Debug.Log ("Call Variable : " + RotateCube.numX);
			Debug.Log ("Call Function : " + RotateCube.AddTwoNum(3, 5));
	    }
	}

}
