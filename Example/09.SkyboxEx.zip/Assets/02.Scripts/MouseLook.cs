﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseLook : MonoBehaviour 
{
	public float sensitivity = 500.0f;
	public float rotationX = 0.0f;
	public float rotationY = 0.0f;

    void Update () 
	{
        // 마우스 좌우로 이동
        float mouseMoveValueX = Input.GetAxis("Mouse X");
        // 마우스 전후로 이동
		float mouseMoveValueY = Input.GetAxis("Mouse Y");

        Debug.Log(mouseMoveValueX);
//        rotationX += mouseMoveValueX * sensitivity * Time.deltaTime;
//		rotationY += mouseMoveValueY * sensitivity * Time.deltaTime;

        // 마우스 앞으로 이동
//        if (rotationY > 45.0f)
//			rotationY = 45.0f;	
		// 마우스 뒤로 이동
//		if (rotationY < -20.0f)
//			rotationY = -20.0f;

//		transform.eulerAngles = new Vector3(-rotationY, rotationX, 0.0f);

//        float rotationValue = CrossPlatformInputManager.GetAxis("Horizontal");

//        rotationValue = rotationValue * 20.0f * Time.deltaTime;
//        transform.rotation *= Quaternion.AngleAxis(rotationValue, Vector3.up);
//        transform.eulerAngles = new Vector3(-rotationX, rotationY, 0.0f);

    }
}
