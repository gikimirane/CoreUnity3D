﻿using UnityEngine;
using System.Collections;
using UnityEditor;

public class MyGameManager : MonoBehaviour 
{
	void OnGUI ()
	{
		if (GUI.Button(new Rect(30, 50, 180, 30)," Set Value "))
	    {
			SetData();	
	    }
	    
		if (GUI.Button(new Rect(30, 100, 180, 30)," Get Value "))
	    {
			GetData();
	    }
	}

	void SetData()
	{
		// Key / Value
		PlayerPrefs.SetInt("Score", 100);
		PlayerPrefs.SetString("Name", "홍길동");
	}

	void GetData()
	{
		// Get Value by Key.
		int myScore = PlayerPrefs.GetInt("Score");
		string myName = PlayerPrefs.GetString("Name", "N/A");
	
		if ( EditorUtility.DisplayDialog("알림", "출력할 내용을 선택하세요.", "이름", "점수") )
		{
			Debug.Log("Name : " + myName);
		} else {
			Debug.Log("Score : " + myScore);
		}

	}

}

/*

* PlayerPrefs 저장 위치

MAC OS
 ㄴ 어플리케이션 : ~/Library/Preferences
 ㄴ 웹플레이어 : ~/Library/Preferences/Unity/WebPlayerPrefs

unity.[company name].[product name].plist 파일


Windows OS
 ㄴ 어플리케이션 : 레지스트리 HKCU\Software\
 ㄴ 웹플레이어 : %APPDATA%\Unity\WebPlayerPrefs

\[company name]\[product name] 폴더


* 세션의 저장과 액세스 사이에 플레이어 환경설정입니다.

Mac OS X에서 PlayerPrefs는 unity.[company name].[product name].plist 이름으로된 파일에,
~/Library/Preferences 폴더에 저장되는, 회사와 제품 이름은 프로젝트에서 설정한 이름입니다.
같은 .plist파일이 프로젝트가 에디터에서 실행하고 독립 플레이어 사이에서 사용됩니다. 

윈도우에서 독립 플레이어, PlayerPrefs는 HKCU\Software\[company name]\[product name] 키를
아래의 레지스트리에 저장됩니다.
회사와 제품 이름은 프로젝트에 설정한 이름입니다. 
웹에서 플레이어, PlayerPrefs가 Mac OS X에서 ~/Library/Preferences/Unity/WebPlayerPrefs
바이너리 파일 아래에 저장되고 윈도우에서는 %APPDATA%\Unity\WebPlayerPrefs에서 저장됩니다.

파일 크기가 1메가바이트로 제한되고 웹 플레이어 URL 파일 당 하나의 환경설정 파일입니다.
만약 이 제한이 초과된다면, SetInt, SetFloat과 SetString이 값을 저장되지 않으며
PlayerPrefsException을 던집니다.

*/