﻿using UnityEngine;
using System.Collections;

public class MainScript : MonoBehaviour 
{
	public Transform spawnPoint;
	public GameObject myParticle;

	void Update () 
	{
		if (Input.GetButtonDown("Fire1")) 
		{
			DoMyParticle();
		}        
	}

	void DoMyParticle ()
	{
		//GameObject particleObj = 
		//             Instantiate(myParticle, spawnPoint.position, spawnPoint.rotation)
		//             as GameObject;
		GameObject particleObj = Instantiate(myParticle) as GameObject;
		particleObj.transform.position = spawnPoint.position;

		Destroy (particleObj, 4.0f);
	}
}
