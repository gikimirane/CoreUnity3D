﻿using UnityEngine;
using System.Collections;

public class FindChild : MonoBehaviour {

	public Transform[] SpawnPoint;

	void Start () {
		SpawnPoint = GameObject.Find ("SpawnPoint").GetComponentsInChildren<Transform>();	

		for (int i = 0; i < SpawnPoint.Length; i++) {
			Debug.Log (SpawnPoint[i].gameObject.name);
		}
	}	
}
