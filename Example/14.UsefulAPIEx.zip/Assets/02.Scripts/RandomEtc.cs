﻿using UnityEngine;
using System.Collections;

public class RandomEtc : MonoBehaviour {

	void Start () {
		// 범위 제한
		// 현재값이 최대값보다 크면 그 최대값까지만 출력해주고
		// 최소값보다 작으면 그 최소값으로만 출력
		int myVal = 10;

		float nLimit = Mathf.Clamp(myVal, 1, 5);
		Debug.Log("Clamps : " + nLimit);



		// 랜덤값 구하기
		int randomSeedS;
		randomSeedS = (int)System.DateTime.Now.Ticks;
		Random.InitState(randomSeedS);

		// Random.Range(이상, 미만)
		int randomX = Random.Range(5, 10);
		Debug.Log("integer : " + randomX);

		float randomY = Random.Range(5.0f, 10.0f);
		Debug.Log("float : " + randomY);
	
	}

}
