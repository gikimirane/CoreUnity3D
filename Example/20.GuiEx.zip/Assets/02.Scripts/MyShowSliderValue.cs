﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MyShowSliderValue : MonoBehaviour {

	Text lbl;

	void Start () {
		lbl = GetComponent<Text>();
	}

	public void UpdateLabel (float value)
	{
		if (lbl != null)
			lbl.text = Mathf.RoundToInt (value * 10) + "%";
	}
}
