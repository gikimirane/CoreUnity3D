﻿using UnityEngine;
using System.Collections;

public class CollisionCheck : MonoBehaviour {

	// 충돌이 일어나려면 두 오브젝트 모두 Collider 를 가져야 하고
	// 둘 중 하나는 Rigidbody 를 가져야 한다.
	// 그리고 Rigidbody 를 가진 쪽이 움직여서 서로 만날 경우만 이벤트가 발생한다.

	void OnCollisionEnter(Collision collision)
	{
		Debug.Log("OnCollisionEnter");
	}

	void OnTriggerEnter(Collider other)
	{
		Debug.Log("OnTriggerEnter");
	}

}
