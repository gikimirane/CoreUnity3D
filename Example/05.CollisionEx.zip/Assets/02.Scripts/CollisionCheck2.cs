﻿using UnityEngine;
using System.Collections;

public class CollisionCheck2 : MonoBehaviour {

	void OnTriggerEnter(Collider other) {
		Debug.Log("OnTriggerEnter");

		GetComponent<Rigidbody>().isKinematic = false;
		GetComponent<Rigidbody>().AddForce(new Vector3 (0.0f, 200.0f, -200.0f));
	}
}

/*
Collision Detection: 충돌을 감지하기 위한 방법을 지정.
                     종류에는 세가지가 있음.
                     빠르게 움직일 경우, 물체와의 충돌을 감지하기도 전에
                     물체를 통과해버리는 상황이 벌어질 수도 있기때문에
                     세가지 방식으로 충돌을 조정 할 수 있음.

 *Discrete : 가장 일반적이면서 빠른 충돌 탐지 방식.
 *Continous: 동적 콜라이더(리지드 바디 있음)에는 Discrete(불연속) 충돌,
             정적 메쉬 콜라이더(리지드바디 없음)에는 Continuous(연속) 충돌을 적용한다.
             물리 연산 성능에 크게 영향을 주기 때문에
             빠른 오브젝트 충돌로 문제가 있지 않으면 Discrete로 설정 하는게 낫다.
 *Continous Dynamic:
             Continuous 및 Continuous Dynamic 충돌을 적용한 오브젝트에 대해
             Continuous 충돌 감지를 수행한다.
             정적 메쉬 콜라이더(리지드 바디 없음)에도 Continuous 충돌을 적용한다.
             다른 콜라이더에 대해서는 Discrete 충돌 감지를 한다.
             고속으로 움직이는 오브젝트에 사용한다. 
*/
