﻿using UnityEngine;
using System.Collections;

public class DynamicChange : MonoBehaviour {

	public Material[] _M_Top1;
	public GameObject _Top1;
	int nTop1 = 0;

	public void ChangeTop1() {
		nTop1++;

		if ( nTop1 > _M_Top1.Length - 1 ) {
			nTop1 = 0;
		}

		CharMaterialSet( _Top1, _M_Top1[nTop1] );
	}

	void CharMaterialSet (GameObject obj, Material mat) {

		obj.GetComponent<Renderer>().material = mat;
	}
}
