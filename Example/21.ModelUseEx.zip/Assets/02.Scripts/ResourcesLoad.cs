﻿using UnityEngine;
using System.Collections;

public class ResourcesLoad : MonoBehaviour {

	string[] _M_Top1 = {
		"Images/female_top-1_blue",
		"Images/female_top-1_green",
		"Images/female_top-1_pink" };

	public GameObject _Top1;
	int nTop1 = 0;

	public void ChangeTop1() {
		nTop1++;

		if ( nTop1 > _M_Top1.Length - 1 ) {
			nTop1 = 0;
		}

		CharMaterialSet( _Top1, _M_Top1[nTop1] );
	}

	void CharMaterialSet (GameObject obj, string mat) {

		obj.GetComponent<Renderer>().material.mainTexture
								= Resources.Load( mat ) as Texture;
	}
}

/*
// 텍스쳐 구하기 #1
gameObject.GetComponent<Renderer>().material.mainTexture = Resources.Load("back") as Texture;


// 텍스쳐 구하기 #2
gameObject.GetComponent<Renderer>().material.mainTexture = Resources.Load("sky" + n, typeof(Texture2D));
*/
