﻿using UnityEngine;
using System.Collections;

public class KeyMove : MonoBehaviour {

	void Update () {
		// Horizontal - Z axis
		transform.rotation *= Quaternion.AngleAxis( Input.GetAxis("Horizontal") *
		                                           30.0f * -1 *
		                                           Time.deltaTime,
		                                           Vector3.forward );
		
		// Vertical - X axis 
		transform.rotation *= Quaternion.AngleAxis( Input.GetAxis("Vertical") *
		                                           30.0f * -1 *
		                                           Time.deltaTime,
		                                           Vector3.left );

//		Vector3 dir = Vector3.zero;
//		dir.x = -Input.acceleration.y;
//		dir.z = Input.acceleration.x;
//		if (dir.sqrMagnitude > 1)
//			dir.Normalize();
//
//		dir *= Time.deltaTime;
////		transform.Translate(dir * 10.0f);
//		transform.Rotate(dir * 10.0f);
	}


}

/*
sqrMagnitude : Returns the squared length of this vector (Read Only).
Normalize() : 
    Makes this vector have a magnitude of 1.
    When normalized, a vector keeps the same direction but its length is 1.0.
*/
