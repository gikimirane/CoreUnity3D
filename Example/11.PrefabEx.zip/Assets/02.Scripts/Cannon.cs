﻿using UnityEngine;
using System.Collections;

public class Cannon : MonoBehaviour 
{
	float power = 900.0f;
	Vector3 velocity = new Vector3(0.0f, 0.3f, 0.5f);

	void Start() 
	{
		velocity = velocity * power;

		GetComponent<Rigidbody>().AddForce( velocity );
	}

	void FixedUpdate() 
	{
		if (this.transform.position.z > 10.0f)
		{
			Destroy(this.gameObject);
		}
	}
}
