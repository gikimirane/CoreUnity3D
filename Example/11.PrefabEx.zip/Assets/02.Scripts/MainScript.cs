﻿using UnityEngine;
using System.Collections;

public class MainScript : MonoBehaviour 
{
	public Transform firePos;
	public GameObject cannon;

	void Update () 
	{
		if (Input.GetButtonDown("Fire1")) 
		{
			//GameObject obj = Instantiate(cannon, firePos.position, firePos.rotation) as GameObject;
			Instantiate(cannon, firePos.position, firePos.rotation);
		}        
	}
}
