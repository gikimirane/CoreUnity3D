﻿using UnityEngine;
using System.Collections;

public class CollisionCheck : MonoBehaviour {

	void OnCollisionEnter(Collision collision)
	{
		Debug.Log("OnCollisionEnter");
	}

	void OnTriggerEnter(Collider other) {
		Debug.Log("OnTriggerEnter");
	}

	void OnControllerColliderHit(ControllerColliderHit hit) {
		if (hit.collider.gameObject.tag == "WALL") {
			Debug.Log ("OnControllerColliderHit");
		}
	}
}

/*
Rigidbody 와 CharacterController 의 차이 :
CC 는 이동중에 부딪쳐서 멈출 수 있지만, 물리객체가 아니므로 부딪친 객체를 밀 수는 없다.
*/

/*
05-Collision3 Scene :
벽이 다가와서 부딪히면 OnControllerColliderHit 가 발생하지 않는다.
Box Collider에 "is Trigger"가 체크되어 있다면 OnTriggerEnter 는 발생한다.
*/
