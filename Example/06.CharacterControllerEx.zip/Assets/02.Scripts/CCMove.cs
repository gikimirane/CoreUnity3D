﻿using UnityEngine;
using System.Collections;

public class CCMove : MonoBehaviour {

	public float movSpeed = 5.0f;
	public float rotSpeed = 120.0f;

	CharacterController controller;
	Vector3 moveDirection;

	float jumpSpeed = 10.0f; 	// jump speed
	float gravity = 20.0f;		// gravity

	void Start () 
	{
		controller = GetComponent<CharacterController>();
	}

	void Update() {
		if (controller.isGrounded) {
			float amtRot  = rotSpeed * Time.deltaTime;

			float ver = Input.GetAxis("Vertical");
			float ang = Input.GetAxis("Horizontal");

			transform.Rotate(Vector3.up * ang * amtRot);

			moveDirection = new Vector3(0, 0, ver * movSpeed);
			moveDirection = transform.TransformDirection(moveDirection);

			if (Input.GetButton("Jump"))
				moveDirection.y = jumpSpeed;
		}

		moveDirection.y -= gravity * Time.deltaTime;

		controller.Move(moveDirection * Time.deltaTime);
	}

}

/*
TransformDirection : Transforms direction from local space to world space.
 
csMove 는 transform을 이용하여 강제로 위치를 변경한 것이고,
csCCMove 는 캐릭터 컨트롤러의 이동 방향과 거리를 결정하고,
캐릭터컨트롤러에게 이동방향과 거리를 알려주는 것이다.
캐릭터컨트롤러는 이동방향과 거리가 올바르면 이동하게 된다.
즉 Slope Limit 를 초과하지 않으면 이동, 초과하면 이동하지 않는다.
*/
