﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate1 : MonoBehaviour {

	void Start () {
        // Transform 초기화 : 회전 #1
        transform.eulerAngles = new Vector3(0.0f, 50.0f, 0.0f);
        //transform.eulerAngles = new Vector3(0.0f, 720.0f, 0.0f);

        // Transform 초기화 : 회전 #2
        // rotation은 Quaternion 값으로 대입해 주어야 한다.
        Quaternion target = Quaternion.Euler(0.0f, 100.0f, 0.0f);
        transform.rotation = target;
        //transform.rotation = Quaternion.AngleAxis(50.0f,Vector3.up);

        // Transform 초기화 : 회전 #3
        // 월드 좌표 혹은 부모 축에 완벽히 정렬
        //transform.rotation = Quaternion.identity;

        // 회전
        transform.Rotate(Vector3.up * 90.0f);
        //transform.Rotate(Vector3.up * 710.0f);
    }
}
