﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move1 : MonoBehaviour {

	void Start () {
        // Transform 초기화 : 이동
        // 해당 Vector의 값으로 이동하여 위치하게 됨
        transform.position = new Vector3(0.0f, 0.5f, 1.0f);

        // 이동
        // 현재 위치에서 주어진 값만큼 이동
        transform.Translate(Vector3.forward * 1.0f);
    }
}
