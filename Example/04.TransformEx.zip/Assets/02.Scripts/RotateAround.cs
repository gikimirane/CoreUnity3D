﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateAround : MonoBehaviour {

    // Cube1 을 선택하고 Local 좌표계를 선택해 놓고 테스트해야 한다.

    Transform obj = null;

    void Start()
    {
        // 찾기
        obj = GameObject.Find("Cube2").transform;
    }

    void Update()
    {
        // 주변 돌기 1
        //transform.RotateAround(Vector3.zero, Vector3.up, 40 * Time.deltaTime);

        // 주변 돌기 2
        transform.RotateAround(obj.position, Vector3.up, 40 * Time.deltaTime);

        transform.LookAt(obj);
    }
}
