﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump1 : MonoBehaviour {

    void FixedUpdate()
    {
        if (Input.GetButtonDown("Jump"))
        {
            // 두 객체의 질량 비교
            // 힘을 준 것이 아니기 때문에 질량과는 상관이 없다.
            GetComponent<Rigidbody>().velocity = new Vector3(0, 10, 0);
        }
    }
}
