﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Throw2 : MonoBehaviour {

    void FixedUpdate()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            GetComponent<Rigidbody>().velocity = new Vector3(7, 7, 0);
        }
    }

    // The velocity vector of the rigidbody.
    // In most cases you should not modify the velocity directly,
    // as this can result in unrealistic behaviour

    // AddForce 메서드는 총탄이나 포탄, 공등을 움직일때 편하지만
    // 중간에 멈추지 못하는데
    // GetComponent<Rigidbody>().velocity = new Vector3(0.0f, 0.0f, 0.0f);
    // 와 같이 사용하면 움직임이 멈추게 된다.

    // velocity는 초기화, AddForce는 움직이기에 사용

}
