﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump2 : MonoBehaviour {

    Vector3 velocity = new Vector3(0.0f, 200.0f, 0.0f);

    void FixedUpdate()
    {
        if (Input.GetButtonDown("Jump"))
        {
            // 두 객체의 질량 비교
            // 질량이 2배인 Cube2는 같은 힘을 받아도 적게 점프한다.
            GetComponent<Rigidbody>().AddForce(velocity);
        }
    }

    // 공기저항을 무시하였을 때,
    // 질량과 관계없이 모든 물체는 같은 가속도(=중력가속도)를 가지고 낙하
    // 공기가 없는 달에서 실험을 한다면, 무거운 트럭과 가벼운 깃털은 같은 속도로 낙하

}
