﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAt : MonoBehaviour {

    Transform obj = null;

    void Start()
    {
        // 찾기
        obj = GameObject.Find("Cube2").transform;
    }

    void Update()
    {
        // 주시
        transform.LookAt(obj);
        //this.gameObject.transform.LookAt(obj);
    }
}
