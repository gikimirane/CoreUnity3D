﻿using UnityEngine;
using System.Collections;

public class Legacy1 : MonoBehaviour {

	bool bFast = false;

	public void doWalk () {
		StartCoroutine("coWalk");
	}

	IEnumerator coWalk()
	{
		GetComponent<Animation>().Play("walk");
		yield return new WaitForSeconds(1.5f);
		GetComponent<Animation>().Play("idle");
	}

	public void doAttack () {
		StartCoroutine("coAttack");
	}

	IEnumerator coAttack()
	{
		//GetComponent<Animation>().Play("attack_2");
		GetComponent<Animation>().CrossFade("attack_2", 0.2f);
		yield return new WaitForSeconds(1.5f);
		//GetComponent<Animation>().Play("idle");
		GetComponent<Animation>().CrossFade("idle", 0.2f);
	}

	public void doWalkFast ()
	{
		if ( bFast ) {
			bFast = false;

			GetComponent<Animation>().Stop();
			GetComponent<Animation>()["walk"].speed = 1.0f;
			GetComponent<Animation>()["walk"].wrapMode = WrapMode.Once;

			StartCoroutine("coWalk");
		} else {
			bFast = true;

			GetComponent<Animation>().Stop();
			GetComponent<Animation>()["walk"].speed = 2.0f;
			GetComponent<Animation>()["walk"].wrapMode = WrapMode.Loop;
			GetComponent<Animation>().Play("walk");
		}
	}

}

/*
// 애니메이션 실행
AnimationState PlayQueued(string animation);
AnimationState PlayQueued(string animation, QueueMode queue);
AnimationState PlayQueued(string animation, QueueMode queue, PlayMode mode);

CompleteOthers / PlayNow

animation["Walk"].speed = 4.0f;
animation["Walk"].wrapMode = WrapMode.Loop;
animation.Play("Walk");

animation.PlayQueued("iddle", QueueMode.CompleteOthers);
*/
