﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainScript : MonoBehaviour 
{
	GameObject box;
	string sStatus = "";

	void Start () 
	{
		box = GameObject.Find("BattleShip");
	}
	
	void OnGUI ()
	{
		if ( GUI.Button(new Rect(10, 260, 50, 30), " < ") )
		{
			sStatus = "왼쪽으로 이동합니다.";

			box.transform.Translate(Vector3.left);
		}
		if ( GUI.Button(new Rect(70, 260, 50, 30), " > ") )
		{
			sStatus = "오른쪽으로 이동합니다.";

			box.transform.Translate(Vector3.right);
		}
	    if ( GUI.Button(new Rect(400, 260, 50, 30), " Fire ") )
	    {
			sStatus = "총알이 발사됩니다.";

			GameObject bullet = GameObject.CreatePrimitive(PrimitiveType.Sphere);
	        //bullet.transform.position = new Vector3(0.0f, 0.0f, 0.0f);
	        bullet.transform.position = box.transform.position;
	        bullet.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
	        bullet.name = "bullet";
	        bullet.AddComponent<Bullet>();
	    }

		GUILayout.Label ( sStatus );
	}
}
