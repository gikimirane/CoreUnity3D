﻿using UnityEngine;
using System.Collections;

public class Coroutine1 : MonoBehaviour {

	// 멀티 쓰레드 프로그래밍의 Thread.Sleep 처럼 원하는 시간 후 실행

	void Update () {
		if ( Input.GetButtonDown( "Fire1" ) ) 
		{
			StartCoroutine( "Exam1" );
		}        
	}

	IEnumerator Exam1 ()
	{
		// 이번 렌더링이 끝난후 실행을 원하는 경우
		yield return new WaitForEndOfFrame();

		// 실행원하는 함수나 코드;
		FirstCall();

		// 몇초후 실행 원하는 경우
		yield return new WaitForSeconds(2.0f);

		// 실행원하는 함수나 코드;
		SecondCall();
	}

	void FirstCall () {
		Debug.Log("First ");
	}

	void SecondCall () {
		Debug.Log("Second ");
	}

}

/*
---------------------------------------------------------------------------------
코루틴용 데이터     					엔진이 수행하는 기능
---------------------------------------------------------------------------------
yield return null						다음 프레임까지 대기
yield return new WaitForSeconds(float)	지정된 초 만큼 대기
yield return new WaitForFixedUpdate()	다음 물리 프레임까지 대기
yield return new WaitForEndOfFrame()	모든 렌더링작업이 끝날 때까지 대기
yield return StartCoRoutine(string)		다른 코루틴이 끝날 때까지 대기
yield return new WWW(string)			웹 통신 작업이 끝날 때까지 대기
yield return new AsyncOperation			비동기 작업이 끝날 때까지 대기 ( 씬로딩 )
---------------------------------------------------------------------------------
*/

/*
요약

1.코루틴은 시간에 따라 혹은 외부의 처리가 완료되었을 때, 연산이 일어나는 순서를 정하는 방법이다.

2.코루틴은 쓰레드가 아니다. 그리고 비동기가 아니다. (동시에 일어나지 않는다.)

3.코루틴이 실행되고 있을 때, 다른 어떤 것들도 실행되지 않는다.

4.코루틴은 yield 문의 조건을 만족시켰을 때, 재개될 것이다.

5.코루틴은 스크립트가 비활성화(disabled)되거나, 객체가 파괴되었을 때, 비활성화 된다.

6.yield return new WaitForSeconds는 Time.timeScale에 의해 영향을 받는다.

*/

/*
마치 멀티 쓰레드 프로그래밍의 Thread.Sleep 함수처럼 원하는 시간만큼 잠들어 있을 수 있다.
하지만 더욱 좋은 점은 엔진과 동일한 싱글 쓰레드로 돌아가기 때문에,
멀티 쓰레드 프로그래밍의 어려운 부분인 자원 관리 및 컨텍스트 스위칭(Context Switching)과
같은 다양한 고려 사항들을 신경쓸 필요가 없다.
*/
