﻿using UnityEngine;
using System.Collections;

public class Coroutine3 : MonoBehaviour {

	// 비동기 작업이 끝날 때까지 대기

	public string url;
	WWW www;

	IEnumerator Start()
	{
		www = new WWW( url );
		StartCoroutine( "CheckProgress" );
		yield return www;
		Debug.Log ("Download Completed!");
	}

	IEnumerator CheckProgress()
	{
		Debug.Log ("A: " + www.progress);
		while ( !www.isDone )
		{
			yield return new WaitForSeconds(0.5f);
			Debug.Log ("B: " + www.progress);
		}
	}

}
