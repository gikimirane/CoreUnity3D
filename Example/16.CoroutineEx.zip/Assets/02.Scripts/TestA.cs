﻿using UnityEngine;
using System.Collections;

public class TestA : MonoBehaviour {

	void Start () {
		//Debug.Log( gameObject.GetInstanceID() );
		Debug.Log( gameObject.name + " : 1 ");
		Debug.Log( gameObject.name + " : 2 ");
		Debug.Log( gameObject.name + " : 3 ");
	}
	
}
