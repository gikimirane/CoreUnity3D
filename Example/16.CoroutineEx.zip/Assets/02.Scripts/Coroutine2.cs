﻿using UnityEngine;
using System.Collections;

public class Coroutine2 : MonoBehaviour {

	// 비동기 작업이 끝날 때까지 대기

	public string url;
	WWW www;

	bool isDownloading = false;

	IEnumerator Start()
	{
		www = new WWW( url );
		isDownloading = true;
		yield return www;
		isDownloading = false;
		Debug.Log ("Download Completed!");
	}

	void Update()
	{
		if (isDownloading)
			Debug.Log (www.progress);
	}

}
