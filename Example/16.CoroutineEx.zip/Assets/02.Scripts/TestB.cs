﻿using UnityEngine;
using System.Collections;

public class TestB : MonoBehaviour {

	IEnumerator Start () {
		Debug.Log( gameObject.name + " : 1 ");
		yield return null;
		Debug.Log( gameObject.name + " : 2 ");
		Debug.Log( gameObject.name + " : 3 ");
	}

}

/*
Start 함수를 IEnumerator로 선언해주면 엔진이 자동으로 코루틴으로 실행해준다.
*/
