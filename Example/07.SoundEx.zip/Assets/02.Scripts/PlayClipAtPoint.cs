﻿using UnityEngine;
using System.Collections;

public class PlayClipAtPoint : MonoBehaviour {

	float speed = 20.0f;

	public Transform box;
	public AudioClip myClip;

	void Update () 
	{
		// 키보드 입력 
		float v = Input.GetAxis("Vertical");

		// 이동거리 보정
		v = v * speed * Time.deltaTime;

		// 실제 이동
		box.Translate(Vector3.forward * v);	

		// Spatial Blend 값이 2D 로 되어 있어도 거리에 따라 소리의 크리가 달라진다.
		// Audio Source 컴포넌트도 필요하지 않다.
		if (Input.GetButtonDown("Fire1")) 
		{
			AudioSource.PlayClipAtPoint(myClip, box.position);
		}        
	}

}
