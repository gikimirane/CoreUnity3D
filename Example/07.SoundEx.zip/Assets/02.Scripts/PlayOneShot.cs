﻿using UnityEngine;
using System.Collections;

public class PlayOneShot : MonoBehaviour {

	public AudioClip clip;

	void OnCollisionEnter(Collision collision)
	{
		//GetComponent<AudioSource>().Play();

		// Play 와 별 차이 없다.
		// The scale of the volume (0-1)

		//GetComponent<AudioSource>().PlayOneShot(clip);
		GetComponent<AudioSource>().PlayOneShot(clip, 0.8f);
	}

}
