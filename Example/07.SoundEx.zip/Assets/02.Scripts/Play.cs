﻿using UnityEngine;
using System.Collections;

public class Play : MonoBehaviour {

	void OnCollisionEnter(Collision collision)
	{
		GetComponent<AudioSource>().Play();
	}

}
