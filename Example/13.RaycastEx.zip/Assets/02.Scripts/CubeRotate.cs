﻿using UnityEngine;
using System.Collections;

public class CubeRotate : MonoBehaviour {

	float accTime = 0.0f;
	bool bRotate = false;

	void Update () {

		if ( accTime > 1.0 ) {
			bRotate = false;
		}

		if ( bRotate ) {
			accTime += Time.deltaTime;

			//transform.rotation *= Quaternion.AngleAxis( 100.0f * Time.deltaTime, Vector3.up );
			transform.Rotate(100.0f * Time.deltaTime * Vector3.up);
		}
	}

	public void RotateByHit () 
	{
		accTime = 0.0f;
		bRotate = true;
	}
}
