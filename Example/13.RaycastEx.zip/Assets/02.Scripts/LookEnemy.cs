﻿using UnityEngine;
using System.Collections;

public class LookEnemy : MonoBehaviour {

	public Transform enemy;
	private Transform viewer;
	private Transform spPoint;

	RaycastHit hit;
	Vector3 fwd = Vector3.forward;
	
	void Start () 
	{
		viewer = transform.Find("/Turret/Viewer");
		spPoint = transform.Find("/Turret/Tower/spawnPoint");
	}
	
	void Update () 
	{
//		transform.LookAt(enemy);
		viewer.LookAt(enemy);
		transform.rotation = viewer.rotation;

		Vector3 newSpPoint = new Vector3(spPoint.position.x,
								 		 viewer.transform.position.y,
		                         		 spPoint.position.z);	

//		Debug.DrawRay(spPoint.position, spPoint.forward * 4, Color.red);
		Debug.DrawRay(newSpPoint, spPoint.forward * 4, Color.red);
		
		fwd = transform.TransformDirection(viewer.transform.forward);
		
		if (Physics.Raycast(newSpPoint, fwd, out hit, 4)) 
		{
			Debug.Log(hit.collider.gameObject.tag);
		}	
	
	}
}

/*
transform.TransformDirection :
Transforms direction from local space to world space.

Vector3.forward;                              					// global
fwd = transform.TransformDirection(viewer.transform.forward);  	// local

*/
