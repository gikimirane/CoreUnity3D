﻿using UnityEngine;
using System.Collections;

public class Raycast : MonoBehaviour {

	private float speed = 5.0f;

	void Update () 
	{
		// 이동
		float amtMove = speed * Time.deltaTime;
		float hor = Input.GetAxis("Horizontal");
		transform.Translate(Vector3.right * hor * amtMove);

		// DrawRay
		Debug.DrawRay(transform.position, transform.forward * 8, Color.red);

		// Raycast
		RaycastHit hit;
		if (Physics.Raycast(transform.position, transform.forward, out hit, 8)) 
		{
			Debug.Log( hit.collider.gameObject.name );
		}	
	}

}

/*

프로그램에서 Raycast를 호출할 때는 다음과 같은 형식을 사용

Physics.Raycast( 기준점, 방향, hitInfo, 거리 ) 		: 가장 가까운 물체 탐색 
Physics.RaycastAll( 기준점, 방향, hitInfo, 거리 ) 	: 전체 탐색 
Physics.Linecast( 시작점, 끝점, hitInfo ) 			: 지정한 범위 탐색


탐색 결과는 RaycastHit Class 에 구해진다. 전체를 탐색한 경우에는 배열로 구해질 것이다.

distance  : 탐지한 물체까지의 거리
collider  : 탐지한 물체의 콜라이더(충돌체) 
rigidbody : 탐지한 물체의 리지드바디 
transform : 탐지한 물체의 위치 정보


레이캐스팅으로 탐지한 물체가 자신이 원하는 오브젝트인가?

collider.gameObject.name 또는
collider.gameObject.tag

*/
