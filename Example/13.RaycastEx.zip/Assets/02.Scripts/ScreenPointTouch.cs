﻿using UnityEngine;
using System.Collections;

public class ScreenPointTouch : MonoBehaviour {

	void Update () {

		if (Input.GetButtonUp("Fire1"))
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;

			if (Physics.Raycast(ray, out hit))
			{
				if (hit.transform.tag.Equals("Enemy")) {
					CubeRotate cubeScript = hit.transform.GetComponent<CubeRotate>();
					if (cubeScript != null) {
						cubeScript.RotateByHit();
					}
				}
			}
		}
	
	}
}
