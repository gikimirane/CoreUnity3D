﻿using UnityEngine;
using System.Collections;

public class RotateAnim : MonoBehaviour {

	public Material mat1;
	public Material mat2;

	void FrontImage() {
		//GetComponent<Renderer>().material.mainTexture = Resources.Load("card1");
		GetComponent<Renderer>().material = mat1;
	}

	void BackImage() {
		//GetComponent<Renderer>().material.mainTexture = Resources.Load("card2");
		GetComponent<Renderer>().material = mat2;
	}

	Animator anim;

	void Start () {
		anim = GetComponent<Animator>();
	}

	void OnMouseUp ()
	{
		StartCoroutine("coAnim");
	}

	IEnumerator coAnim()
	{
		anim.SetInteger( "aniStep", 1 );
		yield return new WaitForSeconds(1.0f);
		anim.SetInteger( "aniStep", 0 );
	}
}
