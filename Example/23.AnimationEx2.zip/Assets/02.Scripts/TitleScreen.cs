﻿using UnityEngine;
using System.Collections;

public class TitleScreen : MonoBehaviour {

	public GUISkin skin;
	private Quaternion originalRotation;

	void Start () 
	{
		originalRotation = transform.localRotation;
	}

	void Update () 
	{
		transform.localRotation =
			Quaternion.AngleAxis (Mathf.Sin (2.0f * Time.time) * 20.0f, Vector3.up) *
			Quaternion.AngleAxis (Mathf.Sin (2.7f * Time.time) * 33.3f, Vector3.right) * 
			originalRotation;

		transform.parent.localRotation = 
			Quaternion.AngleAxis (Time.deltaTime * 10.0f, Vector3.up) *
			transform.parent.localRotation;

		if (Input.GetButtonDown ("Jump")) 
		{
			//Application.LoadLevel("Main");
		}
	}

    void OnGUI()
    {
        GUI.skin = skin;

        int sw = Screen.width;
        int sh = Screen.height;

        GUI.Label(new Rect(0, 0.6f * sh, sw, 0.4f * sh), "PRESS SPACE TO START", "Title");
    }
}

/*
1.프로젝트뷰에서 05.Controllers 선택.
2.에셋 메뉴에서 GUI Skin 선택하여 추가하고 MyGameSkin 으로 이름 변경
3.프로젝트뷰에서 MyGameSkin 선택하고 인스펙터뷰에서 Custom Styles 수정
  3.1 첫번째 Name 에 Title 입력
  3.2 Alignment 를 Middle Center 로 변경
4.하이어라키뷰에서 Title 선택하고 Cs Title Screen 의 Skin 변수에
  프로젝트뷰의 MyGameSkin 연결
*/